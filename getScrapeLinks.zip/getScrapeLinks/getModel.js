const fs = require('fs');

const cheerio = require('cheerio');


const request = require('request');
request('https://www.mediafire.com/file/9g0t6ks5kz7z5lu/RRDB_PSNR_x4.pth/file', function(error, response, body) {
	//console.error('error:', error); // Print the error if one occurred
	console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
	//console.log('body:', body); // Print the HTML for the Google homepage.
	let $ = cheerio.load(body);
	var link = $("#download_link .popsok").attr("href");

	console.log(link);
});


// ESRGAN   https://www.mediafire.com/file/12m9swigl3wk3w7/RRDB_ESRGAN_x4.pth/file

// PSNR		https://www.mediafire.com/file/9g0t6ks5kz7z5lu/RRDB_PSNR_x4.pth/file

/*
let $ = cheerio.load(fs.readFileSync("https://www.mediafire.com/file/2az2uz3t6a3qu28/arbolWallMartBETA.js/file", "UTF-8"));

var link = $("#download_link .popsok").attr("href");

console.log(link);
*/
